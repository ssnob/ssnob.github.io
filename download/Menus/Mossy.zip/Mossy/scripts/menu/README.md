# Elite_Mossy_Menu_Remake-BO3
UPDATE 3: Fixed 2 bugs in the player menu, Re-Download The File!!

UPDATE 2: Removed checks, You can now set stats on all clients in the game aslong as you use MXT Force host, Re-Download The File!!

UPDATE 1: Now Supports Campaign & Fixed A Bug With "2x Movement Speed", Re-Download The File!!

As there is no multiplayer menus released I decided to throw this menu together it's basically an "Elite Mossy Remake" and tried to stick to the style, this menu will work both on MP, ZM & SP just make sure you change the mode in infinity loader to the correct gametype, this menu has just basic mods as I don't want to be working on this menu as it's mainly just for people to do MP unlocks, if you find any bugs let me know and if its game breaking I will fix it. credits to Extinct for the base & Serious for the countless help.
